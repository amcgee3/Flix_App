//
//  ViewController.swift
//  Flix
//
//  Created by Anthony McGee on 10/23/20.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

